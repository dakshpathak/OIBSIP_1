package com.example.unitconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    Button btn;
    TextView tv1,tv2;
    ImageView iv,iv2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = new Intent(this, MainActivity2.class);
        btn = findViewById(R.id.button);
        tv1 = findViewById(R.id.textView2);
        tv2 = findViewById(R.id.textView);
        iv = findViewById(R.id.imageView);
        iv2 = findViewById(R.id.imageView);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Taking you to the main screen!", Toast.LENGTH_SHORT).show();
                startAnimation();
               startActivity(intent);
            }
        });
    }
    private void startAnimation(){
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.anim);
        tv1.startAnimation(animation);
        tv2.startAnimation(animation);
        iv.startAnimation(animation);
        iv2.startAnimation(animation);
        btn.startAnimation(animation);
    }
}