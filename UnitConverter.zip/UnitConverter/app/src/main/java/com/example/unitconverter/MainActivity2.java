package com.example.unitconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    ImageButton ib;
    EditText et;
    TextView tv3;
    int cnt=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        List<String> units1 = Arrays.asList("KM","M","CM","KG","G");
        List<String> units2 = Arrays.asList("KM","M","CM");
        List<String> units3 = Arrays.asList("KG","G");
        List<String> units4 = Arrays.asList("To unit");

        Spinner spinner = findViewById(R.id.spinner);
        Spinner spinner1 = findViewById(R.id.spinner2);

        ib = findViewById(R.id.imageButton2);
        et = findViewById(R.id.editTextNumber);
        tv3 = findViewById(R.id.textView3);

        ArrayAdapter adapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, units1);
        ArrayAdapter adapter2 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, units2);
        ArrayAdapter adapter3 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, units3);
        ArrayAdapter adapter4 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, units4);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinner.setAdapter(adapter);
        spinner1.setAdapter(adapter4);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i==0 || i==1 || i==2){
                    adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinner1.setAdapter(adapter2);
                }
                else{
                    adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinner1.setAdapter(adapter3);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String unit1 = spinner.getSelectedItem().toString();
                String unit2 = spinner1.getSelectedItem().toString();

                String s = et.getText().toString();

                if (cnt == 0) {
                    cnt++;
                    if (s.isEmpty()) {
                        Toast.makeText(MainActivity2.this, "Enter a value!", Toast.LENGTH_SHORT).show();
                    }
                    else {

                        double i = Double.parseDouble(s);
                        switch (unit1) {
                            case ("KM"): {
                                switch (unit2) {
                                    case ("KM"): {
                                        tv3.setText("" + i);
                                        break;
                                    }
                                    case ("M"): {
                                        tv3.setText("" + (i * 1000));
                                        break;
                                    }
                                    case ("CM"): {
                                        tv3.setText("" + (i * 100000));
                                        break;
                                    }
                                    default: {
                                        Toast.makeText(MainActivity2.this, "Enter a valid Unit!", Toast.LENGTH_SHORT).show();
                                        tv3.setText("");
                                        break;
                                    }
                                }

                                break;
                            }
                            case ("M"): {
                                switch (unit2) {
                                    case ("KM"): {
                                        tv3.setText("" + (i / 1000));
                                        break;
                                    }
                                    case ("M"): {
                                        tv3.setText("" + i);
                                        break;
                                    }
                                    case ("CM"): {
                                        tv3.setText("" + (i * 100));
                                        break;
                                    }
                                    default: {
                                        Toast.makeText(MainActivity2.this, "Enter a valid Unit!", Toast.LENGTH_SHORT).show();
                                        tv3.setText("");
                                        break;
                                    }
                                }
                                break;
                            }
                            case ("CM"): {
                                switch (unit2) {
                                    case ("KM"): {
                                        tv3.setText("" + (i / 100000));
                                        break;
                                    }
                                    case ("CM"): {
                                        tv3.setText("" + i);
                                        break;
                                    }
                                    case ("M"): {
                                        tv3.setText("" + (i / 100));
                                        break;
                                    }
                                    default: {
                                        Toast.makeText(MainActivity2.this, "Enter a valid Unit!", Toast.LENGTH_SHORT).show();
                                        tv3.setText("");
                                        break;
                                    }
                                }
                                break;
                            }
                            case ("KG"): {
                                switch (unit2) {
                                    case ("KG"): {
                                        tv3.setText("" + i);
                                        break;
                                    }
                                    case ("G"): {
                                        tv3.setText("" + (i * 1000));
                                        break;
                                    }
                                    default: {
                                        Toast.makeText(MainActivity2.this, "Enter a valid Unit!", Toast.LENGTH_SHORT).show();
                                        tv3.setText("");
                                        break;
                                    }
                                }
                                break;
                            }
                            case ("G"): {
                                switch (unit2) {
                                    case ("G"): {
                                        tv3.setText("" + i);
                                        break;
                                    }
                                    case ("KG"): {
                                        tv3.setText("" + (i / 1000));
                                        break;
                                    }
                                    default: {
                                        Toast.makeText(MainActivity2.this, "Enter a valid Unit!", Toast.LENGTH_SHORT).show();
                                        tv3.setText("");
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
                else{
                    cnt=0;
                    et.setText("");
                    tv3.setText("");
                }
            }




        });


    }
}